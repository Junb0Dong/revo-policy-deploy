"""Standalone-layout inferencer entry point."""

from lerobot.revo.deploy.policy_inferencer import main, serve

__all__ = ["main", "serve"]

if __name__ == "__main__":
    main()
