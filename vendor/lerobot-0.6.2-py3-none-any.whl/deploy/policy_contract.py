"""Standalone-layout alias for the versioned policy contract."""

from lerobot.revo.deploy.policy_contract import *  # noqa: F403
