"""Installable deployment ABI facade for a portable policy artifact."""

from lerobot.revo.deploy.policy_contract import load_contract, payload_hash

__all__ = ["load_contract", "payload_hash"]
