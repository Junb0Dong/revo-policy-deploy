"""Standalone-layout alias for framed stdio protocol helpers."""

from lerobot.revo.deploy.inferencer_protocol import recv_frame, send_frame

__all__ = ["recv_frame", "send_frame"]
