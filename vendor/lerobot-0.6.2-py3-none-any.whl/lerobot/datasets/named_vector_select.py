# Copyright 2026 The HuggingFace Inc. team and contributors.
# Licensed under the Apache License, Version 2.0.

"""Select contiguous state/action vectors by feature names (BrainCo-style transform).

LeRobot stores ``observation.state`` / ``action`` as flat float vectors; per-joint names
live only in ``meta/info.json``. This module resolves ``selected_names → indices`` from
the current dataset metadata and wraps a dataset so ``__getitem__`` returns the selected
sub-vectors. ``dataset.meta.features`` / ``stats`` are patched so ``make_policy`` sees the
selected dimensions (same role as BrainCo's ``TransformedDataset`` + layout slice).
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import numpy as np
import torch
import yaml

from lerobot.utils.constants import ACTION, OBS_STATE

logger = logging.getLogger(__name__)


def resolve_name_indices(source_names: Sequence[str], selected_names: Sequence[str]) -> list[int]:
    """Map ``selected_names`` to indices in ``source_names`` (order = model vector order)."""
    if not selected_names:
        raise ValueError("selected_names must be non-empty")
    if len(set(selected_names)) != len(selected_names):
        dupes = sorted({n for n in selected_names if selected_names.count(n) > 1})
        raise ValueError(f"selected_names contains duplicates: {dupes}")

    index_by_name: dict[str, list[int]] = {}
    for i, name in enumerate(source_names):
        index_by_name.setdefault(name, []).append(i)

    indices: list[int] = []
    missing: list[str] = []
    ambiguous: list[str] = []
    for name in selected_names:
        locs = index_by_name.get(name, [])
        if not locs:
            missing.append(name)
            continue
        if len(locs) > 1:
            ambiguous.append(f"{name}@{locs}")
            continue
        indices.append(locs[0])

    if missing or ambiguous:
        parts = []
        if missing:
            parts.append(f"missing={missing}")
        if ambiguous:
            parts.append(f"ambiguous={ambiguous}")
        raise ValueError(
            "Failed to resolve feature names against dataset metadata: "
            + "; ".join(parts)
            + f". source_names({len(source_names)})={list(source_names)}"
        )
    return indices


def load_feature_select_names(config_path: str | Path) -> tuple[list[str], list[str]]:
    """Load ``io.state_names`` / ``io.action_names`` from a Revo-style YAML recipe."""
    path = Path(config_path)
    with path.open() as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict) or "io" not in cfg:
        raise ValueError(f"{path} must contain a top-level 'io' mapping")
    io = cfg["io"]
    try:
        state_names = list(io["state_names"])
        action_names = list(io["action_names"])
    except KeyError as exc:
        raise ValueError(f"{path} io must define state_names and action_names") from exc
    if not state_names or not action_names:
        raise ValueError(f"{path}: state_names and action_names must be non-empty")
    return state_names, action_names


def _select_last_dim(value: Any, indices: Sequence[int]) -> Any:
    idx = list(indices)
    if isinstance(value, torch.Tensor):
        return value[..., idx]
    if isinstance(value, np.ndarray):
        return value[..., idx]
    if isinstance(value, (list, tuple)):
        arr = np.asarray(value)
        return arr[..., idx]
    raise TypeError(f"Unsupported vector type for name selection: {type(value)}")


def _select_stats_entry(stats: dict[str, Any], indices: Sequence[int]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    idx = list(indices)
    for key, value in stats.items():
        if key == "count":
            out[key] = value
            continue
        arr = np.asarray(value)
        if arr.ndim == 0 or arr.shape == (1,):
            out[key] = value
            continue
        if arr.shape[-1] <= max(idx):
            raise ValueError(
                f"stats entry '{key}' has shape {arr.shape}, cannot index with max={max(idx)}"
            )
        selected = arr[..., idx]
        out[key] = selected.tolist() if isinstance(value, list) else selected
    return out


def apply_name_selection_to_meta(
    meta: Any,
    *,
    state_names: Sequence[str],
    action_names: Sequence[str],
    state_indices: Sequence[int],
    action_indices: Sequence[int],
    source_state_dim: int | None = None,
    source_action_dim: int | None = None,
) -> None:
    """Patch ``meta.features`` and ``meta.stats`` in-place to the selected names/dims."""
    for key, names, indices in (
        (OBS_STATE, state_names, state_indices),
        (ACTION, action_names, action_indices),
    ):
        if key not in meta.features:
            raise KeyError(f"dataset meta is missing feature {key!r}")
        feature = dict(meta.features[key])
        feature["names"] = list(names)
        shape = list(feature.get("shape") or [])
        if not shape:
            feature["shape"] = [len(names)]
        else:
            feature["shape"] = [*shape[:-1], len(names)]
        meta.info.features[key] = feature

        if meta.stats is not None and key in meta.stats:
            meta.stats[key] = _select_stats_entry(meta.stats[key], indices)

    logger.info(
        "Applied name selection: %s %s→%dD, %s %s→%dD",
        OBS_STATE,
        source_state_dim if source_state_dim is not None else "?",
        len(state_names),
        ACTION,
        source_action_dim if source_action_dim is not None else "?",
        len(action_names),
    )


class NamedVectorSelectDataset(torch.utils.data.Dataset):
    """BrainCo-style transform wrapper: resolve names once, slice every sample."""

    def __init__(
        self,
        dataset: torch.utils.data.Dataset,
        state_names: Sequence[str],
        action_names: Sequence[str],
        *,
        patch_meta: bool = True,
    ):
        self._dataset = dataset
        source_state = dataset.meta.features[OBS_STATE]["names"]
        source_action = dataset.meta.features[ACTION]["names"]
        if source_state is None or source_action is None:
            raise ValueError("dataset meta must define names for observation.state and action")

        self.state_names = list(state_names)
        self.action_names = list(action_names)
        self.state_indices = resolve_name_indices(source_state, self.state_names)
        self.action_indices = resolve_name_indices(source_action, self.action_names)
        self._source_state_dim = len(source_state)
        self._source_action_dim = len(source_action)

        if patch_meta:
            apply_name_selection_to_meta(
                dataset.meta,
                state_names=self.state_names,
                action_names=self.action_names,
                state_indices=self.state_indices,
                action_indices=self.action_indices,
                source_state_dim=self._source_state_dim,
                source_action_dim=self._source_action_dim,
            )

        logger.info(
            "NamedVectorSelectDataset: state %s→%s via %s; action %s→%s via %s",
            self._source_state_dim,
            len(self.state_names),
            self.state_indices,
            self._source_action_dim,
            len(self.action_names),
            self.action_indices,
        )

    @property
    def meta(self):
        return self._dataset.meta

    def __len__(self) -> int:
        return len(self._dataset)

    def __getitem__(self, idx):
        item = self._dataset[idx]
        if isinstance(item, list):
            return [self._transform_item(sample) for sample in item]
        return self._transform_item(item)

    def _transform_item(self, item: dict) -> dict:
        if OBS_STATE in item:
            item[OBS_STATE] = _select_last_dim(item[OBS_STATE], self.state_indices)
        if ACTION in item:
            item[ACTION] = _select_last_dim(item[ACTION], self.action_indices)
        return item

    def __getattr__(self, name: str):
        # Avoid recursion during DataLoader worker unpickle (lookups of `_dataset`
        # before __dict__ is restored). Private names must not forward.
        if name.startswith("_"):
            raise AttributeError(name)
        dataset = object.__getattribute__(self, "_dataset")
        return getattr(dataset, name)

    def __getstate__(self):
        return self.__dict__

    def __setstate__(self, state: dict):
        self.__dict__.update(state)


def wrap_dataset_feature_select(
    dataset: torch.utils.data.Dataset,
    *,
    config_path: str | Path | None = None,
    state_names: Sequence[str] | None = None,
    action_names: Sequence[str] | None = None,
) -> NamedVectorSelectDataset:
    """Wrap ``dataset`` using either a Revo YAML path or explicit name lists."""
    if config_path is not None:
        loaded_state, loaded_action = load_feature_select_names(config_path)
        state_names = list(state_names) if state_names is not None else loaded_state
        action_names = list(action_names) if action_names is not None else loaded_action
    if state_names is None or action_names is None:
        raise ValueError("Provide feature_select_config and/or both state_names and action_names")
    return NamedVectorSelectDataset(dataset, state_names, action_names)
