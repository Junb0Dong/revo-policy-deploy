"""Processor glue for task-token conditioning."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import torch

from lerobot.lerobot_types import EnvTransition, TransitionKey
from lerobot.processor.factory import make_default_policy_processor_steps, make_policy_processor_pipelines
from lerobot.processor.pipeline import ProcessorStep, ProcessorStepRegistry


@ProcessorStepRegistry.register("ActionCodecTaskToken")
class ActionCodecTaskTokenProcessorStep(ProcessorStep):
    """Expose LeRobotDataset's task_index under the policy's task_uid name."""

    def __init__(self, task_key: str = "task_index") -> None:
        self.task_key = task_key

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        complementary = transition.get(TransitionKey.COMPLEMENTARY_DATA) or {}
        if self.task_key in complementary:
            complementary = dict(complementary)
            complementary["task_uid"] = complementary[self.task_key]
            transition[TransitionKey.COMPLEMENTARY_DATA] = complementary
        return transition

    def get_config(self) -> dict[str, Any]:
        return {"task_key": self.task_key}

    def transform_features(self, features):
        return features


@ProcessorStepRegistry.register("ActionCodecHistory")
class ActionCodecHistoryProcessorStep(ProcessorStep):
    """Split normalized [-stride,horizon-1] queries; explicit history is ACTION-normalized."""

    def __init__(self, horizon: int = 20, stride: int = 16) -> None:
        self.horizon = horizon
        self.stride = stride

    def __call__(self, transition: EnvTransition) -> EnvTransition:
        transition = dict(transition)
        data = dict(transition.get(TransitionKey.COMPLEMENTARY_DATA) or {})
        action = transition.get(TransitionKey.ACTION)
        if action is not None and action.shape[-2] == self.horizon + self.stride:
            pad = data.get("action_is_pad")
            if pad is None:
                raise ValueError("Temporal action queries require action_is_pad")
            if any(key in data for key in ("previous_chunk", "previous_action", "previous_tokens")):
                raise ValueError("Do not mix extended action queries with explicit history")
            data["previous_chunk"] = action[..., : self.horizon, :]
            data["previous_action"] = action[..., self.stride - 1, :]
            data["previous_token_valid"] = ~pad[..., : self.horizon].bool().any(-1)
            data["previous_action_valid"] = ~pad[..., self.stride - 1].bool()
            data["action_is_pad"] = pad[..., self.stride :]
            transition[TransitionKey.ACTION] = action[..., self.stride :, :]
            if "index" in data:
                data["current_start_index"] = data["index"]
                data["previous_start_index"] = data["index"] - self.stride
        # The generic batch processor does not know the history field dimensions.
        for key, ndim in (
            ("previous_tokens", 1),
            ("previous_chunk", 2),
            ("previous_action", 1),
            ("previous_token_valid", 0),
            ("previous_action_valid", 0),
        ):
            value = data.get(key)
            if isinstance(value, torch.Tensor) and value.ndim == ndim:
                data[key] = value.unsqueeze(0)
        transition[TransitionKey.COMPLEMENTARY_DATA] = data
        return transition

    def get_config(self) -> dict[str, Any]:
        return {"horizon": self.horizon, "stride": self.stride}

    def transform_features(self, features):
        return features


def make_actioncodec_pre_post_processors(config, dataset_stats=None, dataset_meta=None):
    """Build the native LeRobot normalization pipeline plus task-token glue."""
    if config.tokenizer_path is not None and dataset_stats is not None:
        stats = json.loads((Path(config.tokenizer_path) / "action_stats.json").read_text())
        dataset_stats = {
            **dataset_stats,
            "action": {
                **dataset_stats.get("action", {}),
                **{key: torch.tensor(stats[key], dtype=torch.float32) for key in ("mean", "std")},
            },
        }
    steps = make_default_policy_processor_steps(config, dataset_stats)
    preprocessor, postprocessor = make_policy_processor_pipelines(
        input_steps=[
            steps.rename_observations,
            steps.add_batch_dim,
            ActionCodecTaskTokenProcessorStep(),
            steps.to_device,
            steps.normalize,
            ActionCodecHistoryProcessorStep(config.horizon, config.n_action_steps),
        ],
        output_steps=[steps.unnormalize, steps.to_cpu],
    )
    return preprocessor, postprocessor
