"""Shared observation, optimizer and temporal contract for Bin and Transformer DP."""

from dataclasses import dataclass, field

from lerobot.configs import FeatureType, NormalizationMode, PolicyFeature, PreTrainedConfig
from lerobot.optim import AdamWConfig
from lerobot.optim.schedulers import ConstantWithWarmupSchedulerConfig, LRSchedulerConfig

_VISION_ENCODERS = ("small_cnn", "resnet_spatial", "oat_exact_robomimic")
_RGB_MODES = ("minus_one_to_one", "zero_to_one", "none")


@dataclass
class ActionChunkConfig(PreTrainedConfig):
    horizon: int = 20
    n_obs_steps: int = 2
    n_action_steps: int = 16
    action_dim: int = 12
    task_conditioning: str = "normalized_scalar_plus_token"
    num_tasks: int = 0
    resize_shape: tuple[int, int] = (128, 128)
    vision_feature_dim: int = 64
    vision_encoder: str = "oat_exact_robomimic"
    spatial_num_kp: int = 32
    rgb_mode: str = "minus_one_to_one"
    embed_dim: int = 256
    n_layers: int = 4
    n_heads: int = 4
    dropout: float = 0.1
    task_token_init_seed: int = 42
    optimizer_lr: float = 5e-5
    optimizer_lr_obs_encoder: float = 1e-5
    optimizer_weight_decay: float = 0.0
    optimizer_betas: tuple[float, float] = (0.9, 0.95)
    optimizer_grad_clip_norm: float = 1.0
    scheduler_warmup_steps: int = 100
    normalization_mapping: dict[str, NormalizationMode] = field(
        default_factory=lambda: {
            "VISUAL": NormalizationMode.IDENTITY,
            "STATE": NormalizationMode.MIN_MAX,
            "ACTION": NormalizationMode.MIN_MAX,
        }
    )

    def __post_init__(self) -> None:
        super().__post_init__()
        if (self.horizon, self.n_obs_steps, self.n_action_steps) != (20, 2, 16):
            raise ValueError("Action chunk contract requires horizon=20, n_obs_steps=2, n_action_steps=16")
        if self.embed_dim % self.n_heads:
            raise ValueError("embed_dim must be divisible by n_heads")
        if self.task_conditioning != "normalized_scalar_plus_token":
            raise ValueError("Action chunk uses task-token conditioning")
        if self.vision_encoder not in _VISION_ENCODERS:
            raise ValueError(
                f"Unsupported vision_encoder={self.vision_encoder!r}; expected one of {_VISION_ENCODERS}"
            )
        if self.rgb_mode not in _RGB_MODES:
            raise ValueError(f"Unsupported rgb_mode={self.rgb_mode!r}; expected one of {_RGB_MODES}")
        if len(self.resize_shape) != 2 or any(int(size) <= 0 for size in self.resize_shape):
            raise ValueError(f"resize_shape must be a pair of positive integers, got {self.resize_shape}")

    @property
    def observation_delta_indices(self) -> list[int]:
        return list(range(-(self.n_obs_steps - 1), 1))

    @property
    def action_delta_indices(self) -> list[int]:
        return list(range(self.horizon))

    @property
    def reward_delta_indices(self) -> None:
        return None

    def get_optimizer_preset(self) -> AdamWConfig:
        return AdamWConfig(
            lr=self.optimizer_lr,
            weight_decay=self.optimizer_weight_decay,
            betas=self.optimizer_betas,
            grad_clip_norm=self.optimizer_grad_clip_norm,
        )

    def get_scheduler_preset(self) -> LRSchedulerConfig:
        return ConstantWithWarmupSchedulerConfig(num_warmup_steps=self.scheduler_warmup_steps)

    def validate_features(self) -> None:
        if not self.image_features:
            raise ValueError("Action chunk requires at least one observation image")
        if self.action_feature is None or tuple(self.action_feature.shape) != (self.action_dim,):
            raise ValueError(f"Action chunk requires action shape ({self.action_dim},)")
        if not self.state_features:
            raise ValueError("Action chunk requires at least one STATE observation feature")
        if self.num_tasks < 1:
            raise ValueError("Action chunk task-token conditioning requires num_tasks >= 1")

    @property
    def state_features(self) -> dict[str, PolicyFeature]:
        """STATE inputs in declared metadata order.

        RoboCasa OAT-4 stores proprioception in three separate features; older datasets
        expose the same values as one ``observation.state`` feature.
        """
        if not self.input_features:
            return {}
        return {
            key: feature for key, feature in self.input_features.items() if feature.type is FeatureType.STATE
        }
