"""Shared OAT optimizer grouping and online observation/action queues."""

from collections import deque
from typing import Any

import torch

from lerobot.lerobot_types import PolicyAction
from lerobot.utils.constants import ACTION


class ActionChunkMixin:
    def get_optim_params(self) -> list[dict[str, Any]]:  # type: ignore[override]
        policy_decay, policy_nodecay, obs_decay, obs_nodecay = [], [], [], []
        for name, param in self.named_parameters():
            if not param.requires_grad:
                continue
            is_obs = name.startswith("obs_encoder.")
            decay = param.ndim >= 2
            if is_obs and decay:
                obs_decay.append(param)
            elif is_obs:
                obs_nodecay.append(param)
            elif decay:
                policy_decay.append(param)
            else:
                policy_nodecay.append(param)
        groups = [
            {
                "params": policy_decay,
                "lr": self.config.optimizer_lr,
                "weight_decay": self.config.optimizer_weight_decay,
                "name": "policy_decay",
            },
            {
                "params": policy_nodecay,
                "lr": self.config.optimizer_lr,
                "weight_decay": 0.0,
                "name": "policy_nodecay",
            },
            {
                "params": obs_decay,
                "lr": self.config.optimizer_lr_obs_encoder,
                "weight_decay": self.config.optimizer_weight_decay,
                "name": "obs_decay",
            },
            {
                "params": obs_nodecay,
                "lr": self.config.optimizer_lr_obs_encoder,
                "weight_decay": 0.0,
                "name": "obs_nodecay",
            },
        ]
        return [group for group in groups if len(group["params"]) > 0]

    def reset(self) -> None:
        """Clear action and online observation history at an episode boundary."""
        self._action_queue.clear()
        self._observation_queues = {
            key: deque(maxlen=self.config.n_obs_steps)
            for key in [*self.config.image_features, *self.config.state_features]
        }

    def _update_observation_history(self, batch: dict[str, torch.Tensor]) -> None:
        """Append one live observation, or seed history from an explicit temporal batch."""
        for key, queue in self._observation_queues.items():
            if key not in batch:
                raise KeyError(f"{key} is required for ActionCodec online inference")
            value = batch[key]
            live_ndim = 4 if key in self.config.image_features else 2
            if value.ndim == live_ndim + 1:
                if value.shape[1] != self.config.n_obs_steps:
                    raise ValueError(
                        f"{key} temporal input must have {self.config.n_obs_steps} steps, "
                        f"got shape {tuple(value.shape)}"
                    )
                queue.clear()
                queue.extend(value[:, index] for index in range(self.config.n_obs_steps))
                continue
            if value.ndim != live_ndim:
                raise ValueError(
                    f"{key} live input must have {live_ndim} dimensions, got shape {tuple(value.shape)}"
                )
            if not queue:
                queue.extend(value for _ in range(self.config.n_obs_steps))
            else:
                queue.append(value)

    def _online_batch(self, batch: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        """Build a two-step policy batch from the online history queues."""
        online = dict(batch)
        for key, queue in self._observation_queues.items():
            if len(queue) != self.config.n_obs_steps:
                raise RuntimeError(f"{key} observation history is not initialized")
            online[key] = torch.stack(tuple(queue), dim=1)
        online.pop(ACTION, None)
        return online

    def _task_ids(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        value = batch.get("task_uid", batch.get("task_index"))
        if value is None:
            raise KeyError("task_uid is required for ActionCodec")
        if value.ndim == 2 and value.shape[-1] == 1:
            value = value[:, 0]
        return value.long()

    @torch.no_grad()
    def select_action(self, batch: dict[str, torch.Tensor]) -> PolicyAction:
        """Update observation history and return the next action from the current chunk."""
        self.eval()
        self._update_observation_history(batch)
        if not self._action_queue:
            chunk = self.predict_action_chunk(self._online_batch(batch))[:, : self.config.n_action_steps]
            self._action_queue.extend(chunk.transpose(0, 1))
        return self._action_queue.popleft()
