"""Variable-length categorical FAST policy using the existing OAT core and KV cache."""

from collections import deque
from copy import copy
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F  # noqa: N812

from lerobot.policies.actioncodec.modeling_actioncodec import ActionCodecPolicy, OATExactCached
from lerobot.policies.actioncodec.obs_encoder import ObservationEncoder
from lerobot.policies.pretrained import PreTrainedPolicy
from lerobot.utils.constants import ACTION

from .configuration_fast import FastConfig
from .tokenizer import FastDecodeError, FittedFastTokenizer


class FastOATCached(OATExactCached):
    def __init__(self, config, cond_dim, tokenizer):
        core_config = copy(config)
        core_config.codebook_size = tokenizer.vocab_size + 2
        core_config.latent_horizon = config.max_seq_len - 1
        super().__init__(core_config, cond_dim)
        self.generation_vocab_size = tokenizer.vocab_size + 1  # BPE + EOS only
        self.eos_id, self.pad_id = tokenizer.eos_id, tokenizer.pad_id

    @torch.inference_mode()
    def generate(self, input_ids, cond, max_new_tokens, task_ids, temperature=1.0, top_k=10):
        if input_ids.shape[1] != 1 or max_new_tokens > self.max_seq_len:
            raise ValueError("FAST generation requires a single BOS and a valid token budget")
        memory = self._memory(cond, task_ids)
        memory_cache = [block.memory_kv(memory) for block in self.blocks]
        past = [None] * len(self.blocks)
        result = input_ids
        done = torch.zeros(len(input_ids), dtype=torch.bool, device=input_ids.device)
        for position in range(max_new_tokens):
            x = self.drop(self.token_emb(result[:, -1:]) + self.token_pos_emb[:, position : position + 1])
            for layer, block in enumerate(self.blocks):
                x, past[layer] = block(x, memory, past[layer], memory_cache[layer])
            scores = self.head(self.norm(x))[:, -1, : self.generation_vocab_size]
            if temperature > 0:
                scores = scores / temperature
                if 0 < top_k < scores.shape[-1]:
                    threshold = scores.topk(top_k, dim=-1).values[:, -1:]
                    scores = scores.masked_fill(scores < threshold, -torch.inf)
                next_id = torch.multinomial(scores.softmax(-1), 1).squeeze(1)
            else:
                next_id = scores.argmax(-1)
            next_id = torch.where(done, self.pad_id, next_id)
            result = torch.cat((result, next_id[:, None]), dim=1)
            done |= next_id == self.eos_id
            if done.all():
                break
        return result


def sequence_cross_entropy(logits, targets, pad_id):
    valid = targets != pad_id
    counts = valid.sum(-1)
    if (counts == 0).any():
        raise ValueError("FAST targets must contain EOS")
    ce = F.cross_entropy(logits.transpose(1, 2).float(), targets, ignore_index=pad_id, reduction="none")
    return (ce.sum(-1) / counts).mean()


class FastPolicy(ActionCodecPolicy):
    config_class = FastConfig
    name = "fast"

    def __init__(self, config, dataset_stats=None, dataset_meta=None, checkpoint_root=None, **kwargs):
        if config.tokenizer_path is None:
            raise ValueError("FAST requires a fitted tokenizer_path")
        config.tokenizer_path = Path(config.tokenizer_path)
        bundled = None if checkpoint_root is None else Path(checkpoint_root) / "tokenizer"
        # A resumed train_config may retain the original absolute fit path. Checkpoint
        # contents are authoritative, including after the entire run directory moves.
        if bundled is not None and (bundled / "artifact.json").is_file():
            config.tokenizer_path = bundled
        elif not config.tokenizer_path.is_absolute() and checkpoint_root is not None:
            config.tokenizer_path = Path(checkpoint_root) / config.tokenizer_path
        if dataset_meta is not None and config.num_tasks == 0:
            config.num_tasks = int(dataset_meta.total_tasks)
        PreTrainedPolicy.__init__(self, config)
        config.validate_features()
        self.tokenizer = FittedFastTokenizer(config.tokenizer_path)
        if self.tokenizer.shape != (config.horizon, config.action_dim):
            raise ValueError("FAST artifact shape differs from policy")
        self.obs_encoder = ObservationEncoder(config)
        self.model = FastOATCached(config, self.obs_encoder.output_dim, self.tokenizer)
        self._action_queue = deque(maxlen=config.n_action_steps)
        self._observation_queues = {}
        self.reset()

    def forward(self, batch):
        action = batch[ACTION]
        if "action_is_pad" in batch and batch["action_is_pad"].any():
            raise ValueError("FAST training cannot use padded episode-tail actions")
        sequences = self.tokenizer.encode(action.detach().float().cpu().numpy())
        lengths = [len(ids) + 1 for ids in sequences]
        if max(lengths) > self.config.max_seq_len:
            raise ValueError(f"FAST target length {max(lengths)} exceeds max_seq_len; truncation forbidden")
        targets = torch.full(
            (len(sequences), max(lengths)), self.tokenizer.pad_id, dtype=torch.long, device=action.device
        )
        for index, ids in enumerate(sequences):
            targets[index, : lengths[index]] = torch.tensor(
                [*ids, self.tokenizer.eos_id], device=action.device
            )
        bos = torch.full((len(sequences), 1), self.tokenizer.bos_id, dtype=torch.long, device=action.device)
        inputs = torch.cat((bos, targets[:, :-1]), dim=1)
        logits = self.model(inputs, self.obs_encoder(batch), self._task_ids(batch))
        loss = sequence_cross_entropy(logits, targets, self.tokenizer.pad_id)
        valid = targets != self.tokenizer.pad_id
        accuracy = (((logits.argmax(-1) == targets) & valid).sum(-1) / valid.sum(-1)).float().mean()
        return loss, {
            "ce_loss": loss.item(),
            "token_accuracy": accuracy.item(),
            "target_tokens": float(np.mean(lengths)),
        }

    @torch.no_grad()
    def predict_action_chunk_with_diagnostics(self, batch):
        features, task_ids = self.obs_encoder(batch), self._task_ids(batch)
        count = len(features)
        actions = torch.full(
            (count, self.config.horizon, self.config.action_dim), torch.nan, device=features.device
        )
        valid = np.zeros(count, dtype=bool)
        attempts = np.zeros(count, dtype=np.int64)
        candidates_generated = np.zeros(count, dtype=np.int64)
        failures = [None] * count
        for offset in range(0, self.config.decode_retry_attempts, self.config.decode_candidate_batch_size):
            pending = np.flatnonzero(~valid)
            if not len(pending):
                break
            group = min(self.config.decode_candidate_batch_size, self.config.decode_retry_attempts - offset)
            indices = torch.as_tensor(pending, device=features.device)
            cond = features[indices].repeat_interleave(group, dim=0)
            tasks = task_ids[indices].repeat_interleave(group, dim=0)
            bos = torch.full((len(cond), 1), self.tokenizer.bos_id, dtype=torch.long, device=features.device)
            tokens = (
                self.model.generate(
                    bos, cond, self.config.max_seq_len, tasks, self.config.temperature, self.config.top_k
                )[:, 1:]
                .cpu()
                .tolist()
            )
            for local, index in enumerate(pending):
                candidates_generated[index] += group
                for candidate in range(group):
                    attempts[index] += 1
                    try:
                        decoded = self.tokenizer.decode(tokens[local * group + candidate])
                    except FastDecodeError as error:
                        failures[index] = str(error)
                        continue
                    actions[index] = torch.as_tensor(decoded, device=features.device)
                    valid[index] = True
                    failures[index] = None
                    break
        return actions, {
            "valid": valid.tolist(),
            "attempts": attempts.tolist(),
            "candidates_generated": candidates_generated.tolist(),
            "failures": failures,
        }

    @torch.no_grad()
    def predict_action_chunk(self, batch, **kwargs):
        actions, diagnostics = self.predict_action_chunk_with_diagnostics(batch)
        if not all(diagnostics["valid"]):
            raise FastDecodeError(f"FAST decode exhausted retries: {diagnostics}")
        return actions

    @torch.no_grad()
    def select_action(self, batch, **kwargs):
        self.eval()
        self._update_observation_history(batch)
        if not self._action_queue:
            actions = self.predict_action_chunk(self._online_batch(batch))
            self._action_queue.extend(actions[:, : self.config.n_action_steps].transpose(0, 1))
        return self._action_queue.popleft()
