"""Fitted FAST policy."""
