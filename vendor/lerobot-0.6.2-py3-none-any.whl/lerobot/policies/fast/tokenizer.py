"""Offline fitted FAST artifact and strict decoding (no zero-fill fallback)."""

import importlib.util
import json
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from lerobot.utils.import_utils import _scipy_available, _transformers_available, require_package

if TYPE_CHECKING or _scipy_available:
    from scipy.fft import dct, idct
if TYPE_CHECKING or _transformers_available:
    from transformers import PreTrainedTokenizerFast


class FastDecodeError(ValueError):
    """A sampled sequence is not a complete, legal action chunk."""


def load_official_class(source):
    require_package("transformers", extra="fast")
    require_package("scipy", extra="fast")
    spec = importlib.util.spec_from_file_location("fitted_fast_official", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.UniversalActionProcessor


class FittedFastTokenizer:
    def __init__(self, path):
        require_package("transformers", extra="fast")
        require_package("scipy", extra="fast")
        self.path = Path(path)
        self.metadata = json.loads((self.path / "artifact.json").read_text())
        self.stats = json.loads((self.path / "action_stats.json").read_text())
        self.bpe = PreTrainedTokenizerFast.from_pretrained(self.path / "bpe", local_files_only=True)
        self.vocab_size = len(self.bpe)
        self.eos_id, self.bos_id, self.pad_id = range(self.vocab_size, self.vocab_size + 3)
        self.scale = self.metadata["scale"]
        self.min_token = self.metadata["min_token"]
        self.max_token = self.metadata["max_token"]
        self.shape = (self.metadata["horizon"], self.metadata["action_dim"])
        self.official = load_official_class(self.path / "official" / "processing_action_tokenizer.py")(
            self.bpe,
            scale=self.scale,
            vocab_size=self.vocab_size,
            min_token=self.min_token,
            time_horizon=self.shape[0],
            action_dim=self.shape[1],
        )

    def normalize(self, raw):
        lo, hi = (np.asarray(self.stats[k], dtype=np.float32) for k in ("q01", "q99"))
        return np.clip(2 * (np.asarray(raw, dtype=np.float32) - lo) / (hi - lo) - 1, -1, 1)

    def unnormalize(self, normalized):
        lo, hi = (np.asarray(self.stats[k], dtype=np.float32) for k in ("q01", "q99"))
        return (np.asarray(normalized) + 1) * (hi - lo) / 2 + lo

    def coefficient_string(self, action):
        coeff = np.rint(dct(action, axis=0, norm="ortho") * self.scale).astype(int)
        if coeff.min() < self.min_token or coeff.max() > self.max_token:
            raise ValueError("DCT coefficients outside fitted alphabet")
        return "".join(map(chr, (coeff.flatten() - self.min_token).tolist()))

    def encode(self, normalized):
        normalized = np.asarray(normalized, dtype=np.float32)
        if normalized.ndim != 3 or tuple(normalized.shape[1:]) != self.shape:
            raise ValueError(f"Expected [B,{self.shape[0]},{self.shape[1]}]")
        if not np.isfinite(normalized).all() or np.abs(normalized).max() > 1.000001:
            raise ValueError("FAST adapter expects finite, already normalized actions in [-1,1]")
        return self.official(normalized)

    def decode(self, sequence, *, require_eos=True):
        ids = list(map(int, sequence))
        if require_eos:
            if self.eos_id not in ids:
                raise FastDecodeError("missing EOS")
            end = ids.index(self.eos_id)
            if any(i != self.pad_id for i in ids[end + 1 :]):
                raise FastDecodeError("non-PAD token after EOS")
            ids = ids[:end]
        if not ids or any(i < 0 or i >= self.vocab_size for i in ids):
            raise FastDecodeError("empty sequence or invalid token ID")
        string = self.bpe.decode(ids, clean_up_tokenization_spaces=False)
        if len(string) != np.prod(self.shape):
            raise FastDecodeError(f"expected {np.prod(self.shape)} DCT coefficients, got {len(string)}")
        coeff = np.asarray(list(map(ord, string)), dtype=np.int64) + self.min_token
        if np.any(coeff < self.min_token) or np.any(coeff > self.max_token):
            raise FastDecodeError("illegal DCT character")
        action = idct(coeff.reshape(self.shape) / self.scale, axis=0, norm="ortho")
        if not np.isfinite(action).all():
            raise FastDecodeError("non-finite decoded action")
        return np.clip(action, -1, 1).astype(np.float32)
