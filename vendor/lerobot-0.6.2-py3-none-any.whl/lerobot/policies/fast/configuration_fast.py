"""Fitted FAST tokens with the base OAT observation-conditioned decoder."""

from dataclasses import dataclass, field

from lerobot.configs import NormalizationMode, PreTrainedConfig
from lerobot.policies.actioncodec.configuration_actioncodec import ActionCodecConfig


@PreTrainedConfig.register_subclass("fast")
@dataclass
class FastConfig(ActionCodecConfig):
    action_dim: int = 12
    max_seq_len: int = 256  # Target includes EOS, excludes BOS; never truncate.
    decode_retry_attempts: int = 64
    decode_candidate_batch_size: int = 8
    drop_n_last_frames: int = 19
    embed_dim: int = 1024
    n_layers: int = 15
    n_heads: int = 16
    image_size: tuple[int, int] = (96, 128)
    crop_shape: tuple[int, int] | None = None
    temperature: float = 1.0
    top_k: int = 10
    normalization_mapping: dict[str, NormalizationMode] = field(
        default_factory=lambda: {
            "VISUAL": NormalizationMode.IDENTITY,
            "STATE": NormalizationMode.MIN_MAX,
            "ACTION": NormalizationMode.QUANTILES,
        }
    )

    def __post_init__(self):
        super().__post_init__()
        if (
            self.vision_encoder == "resnet18_spatial_tokens"
            or self.state_dropout_prob
            or self.history_dropout_prob
        ):
            raise ValueError("Spatial tokens and condition dropout are ActionCodec-only")
        if self.max_seq_len < 2 or self.decode_retry_attempts < 1 or self.decode_candidate_batch_size < 1:
            raise ValueError("FAST sequence length and retry counts must be positive")
        if self.drop_n_last_frames != self.horizon - 1:
            raise ValueError("FAST requires complete episode-safe action windows")
        if self.quantizer_type != "vq" or any(
            (
                self.condition_on_prev_token,
                self.condition_on_prev_action,
                self.two_chunk_training,
                self.codebook_distance_loss_weight,
                self.decoded_action_loss_weight,
                self.decoded_velocity_loss_weight,
                self.decoded_first_target_loss_weight,
                self.decoded_overlap_loss_weight,
                self.decoded_seam_loss_weight,
            )
        ):
            raise ValueError("FAST supports base categorical CE without history or auxiliary losses")
        if self.normalization_mapping["ACTION"] != NormalizationMode.QUANTILES:
            raise ValueError("FAST requires artifact-matched QUANTILES normalization")
