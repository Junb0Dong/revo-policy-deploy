"""Artifact-matched quantile normalization, clipping and task conditioning."""

import json
from pathlib import Path

import torch

from lerobot.lerobot_types import TransitionKey
from lerobot.policies.actioncodec.processor_actioncodec import ActionCodecTaskTokenProcessorStep
from lerobot.processor.factory import make_default_policy_processor_steps, make_policy_processor_pipelines
from lerobot.processor.pipeline import ProcessorStep


class FastActionClipStep(ProcessorStep):
    def __call__(self, transition):
        action = transition.get(TransitionKey.ACTION)
        if action is not None:
            transition = dict(transition)
            transition[TransitionKey.ACTION] = action.clamp(-1, 1)
        return transition

    def transform_features(self, features):
        return features


def make_fast_pre_post_processors(config, dataset_stats=None, dataset_meta=None):
    stats = json.loads((Path(config.tokenizer_path) / "action_stats.json").read_text())
    dataset_stats = {
        **(dataset_stats or {}),
        "action": {key: torch.tensor(stats[key], dtype=torch.float32) for key in ("q01", "q99")},
    }
    steps = make_default_policy_processor_steps(config, dataset_stats)
    return make_policy_processor_pipelines(
        input_steps=[
            steps.rename_observations,
            steps.add_batch_dim,
            ActionCodecTaskTokenProcessorStep(),
            steps.to_device,
            steps.normalize,
            FastActionClipStep(),
        ],
        output_steps=[FastActionClipStep(), steps.unnormalize, steps.to_cpu],
    )
