"""Epsilon diffusion over normalized action chunks using a Transformer and DDIM."""

from collections import deque
from typing import TYPE_CHECKING, Any, ClassVar

import torch
import torch.nn.functional as F  # noqa: N812

from lerobot.policies.actioncodec.chunk_policy import ActionChunkMixin
from lerobot.policies.actioncodec.obs_encoder import ObservationEncoder
from lerobot.policies.pretrained import PreTrainedPolicy
from lerobot.utils.constants import ACTION
from lerobot.utils.import_utils import _diffusers_available, require_package

from .configuration_diffusion_transformer import DiffusionTransformerConfig
from .denoiser import DiffusionTransformer

if TYPE_CHECKING or _diffusers_available:
    from diffusers.schedulers.scheduling_ddim import DDIMScheduler
else:
    DDIMScheduler = None


class DiffusionTransformerPolicy(ActionChunkMixin, PreTrainedPolicy):
    config_class: ClassVar[type[DiffusionTransformerConfig]] = DiffusionTransformerConfig
    name: ClassVar[str] = "diffusion_transformer"

    def __init__(self, config: DiffusionTransformerConfig, dataset_meta: Any = None, **kwargs: Any) -> None:
        require_package("diffusers", extra="diffusion")
        if dataset_meta is not None and config.num_tasks == 0:
            config.num_tasks = int(dataset_meta.total_tasks)
        config.validate_features()
        super().__init__(config)
        self.obs_encoder = ObservationEncoder(config)
        self._action_queue = deque(maxlen=config.n_action_steps)
        self.reset()
        self.model = DiffusionTransformer(
            input_dim=config.action_dim,
            horizon=config.horizon,
            n_obs_steps=config.n_obs_steps,
            cond_dim=self.obs_encoder.output_dim,
            embed_dim=config.embed_dim,
            n_layers=config.n_layers,
            n_heads=config.n_heads,
            dropout=config.dropout,
            memory_mask_mode=config.memory_mask_mode,
        )
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(config.task_token_init_seed)
            self.task_embedding = torch.nn.Embedding(config.num_tasks, config.embed_dim)
            torch.nn.init.xavier_uniform_(self.task_embedding.weight)
        self.noise_scheduler = DDIMScheduler(
            num_train_timesteps=config.num_train_timesteps,
            beta_schedule=config.beta_schedule,
            prediction_type=config.prediction_type,
            clip_sample=config.clip_sample,
            clip_sample_range=1.0,
            set_alpha_to_one=True,
            steps_offset=0,
        )

    def forward(self, batch: dict[str, torch.Tensor]) -> tuple[torch.Tensor, dict[str, float]]:
        trajectory = batch[ACTION].float().clamp(-1, 1)
        timesteps = torch.randint(
            self.config.num_train_timesteps,
            (trajectory.shape[0],),
            device=trajectory.device,
        )
        noise = torch.randn_like(trajectory)
        noisy = self.noise_scheduler.add_noise(trajectory, noise, timesteps)
        prediction = self.model(
            noisy,
            timesteps,
            self.obs_encoder(batch),
            self.task_embedding(self._task_ids(batch)),
        )
        loss = F.mse_loss(prediction, noise)
        return loss, {"diffusion_mse": loss.detach().item()}

    @torch.no_grad()
    def predict_action_chunk(self, batch: dict[str, torch.Tensor]) -> torch.Tensor:
        self.eval()
        features = self.obs_encoder(batch)
        task_token = self.task_embedding(self._task_ids(batch))
        trajectory = torch.randn(
            features.shape[0],
            self.config.horizon,
            self.config.action_dim,
            device=features.device,
        )
        self.noise_scheduler.set_timesteps(self.config.num_inference_steps, device=features.device)
        for timestep in self.noise_scheduler.timesteps:
            timesteps = timestep.expand(features.shape[0])
            prediction = self.model(trajectory, timesteps, features, task_token)
            trajectory = self.noise_scheduler.step(
                prediction,
                timestep,
                trajectory,
                eta=self.config.eta,
            ).prev_sample
        return trajectory
