"""ActionCodec causal Transformer denoiser with full observation cross-attention."""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F  # noqa: N812


class SinusoidalPosEmb(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.dim = int(dim)

    def forward(self, timesteps: torch.Tensor) -> torch.Tensor:
        half = self.dim // 2
        scale = math.log(10_000.0) / max(half - 1, 1)
        frequencies = torch.exp(-scale * torch.arange(half, device=timesteps.device, dtype=torch.float32))
        angles = timesteps.float().reshape(-1, 1) * frequencies.reshape(1, -1)
        embedding = torch.cat([angles.sin(), angles.cos()], dim=-1)
        if embedding.shape[-1] < self.dim:
            embedding = F.pad(embedding, (0, self.dim - embedding.shape[-1]))
        return embedding


class DiffusionTransformer(nn.Module):
    """OAT-style causal Transformer denoiser for continuous action chunks."""

    def __init__(
        self,
        input_dim: int,
        horizon: int,
        n_obs_steps: int,
        cond_dim: int,
        embed_dim: int = 256,
        n_layers: int = 4,
        n_heads: int = 4,
        dropout: float = 0.1,
        memory_mask_mode: str = "full_observation",
    ):
        super().__init__()
        self.horizon = int(horizon)
        self.n_obs_steps = int(n_obs_steps)
        self.embed_dim = int(embed_dim)
        self.memory_mask_mode = str(memory_mask_mode).strip().lower()
        if self.memory_mask_mode != "full_observation":
            raise ValueError("Only full_observation cross-attention is supported")
        self.input_emb = nn.Linear(int(input_dim), self.embed_dim)
        self.pos_emb = nn.Parameter(torch.zeros(1, self.horizon, self.embed_dim))
        self.cond_obs_emb = nn.Linear(int(cond_dim), self.embed_dim)
        self.cond_pos_emb = nn.Parameter(torch.zeros(1, 1 + self.n_obs_steps, self.embed_dim))
        self.time_emb = SinusoidalPosEmb(self.embed_dim)
        self.cond_encoder = nn.Sequential(
            nn.Linear(self.embed_dim, 4 * self.embed_dim),
            nn.Mish(),
            nn.Linear(4 * self.embed_dim, self.embed_dim),
        )
        layer = nn.TransformerDecoderLayer(
            d_model=self.embed_dim,
            nhead=int(n_heads),
            dim_feedforward=4 * self.embed_dim,
            dropout=float(dropout),
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.decoder = nn.TransformerDecoder(layer, num_layers=int(n_layers))
        self.drop = nn.Dropout(float(dropout))
        self.norm = nn.LayerNorm(self.embed_dim)
        self.head = nn.Linear(self.embed_dim, int(input_dim))
        self.register_buffer("target_mask", self._causal_mask(self.horizon), persistent=False)
        self.register_buffer("memory_mask", self._memory_mask(), persistent=False)
        self._init_weights()

    @staticmethod
    def _causal_mask(size: int) -> torch.Tensor:
        mask = torch.triu(torch.ones(size, size), diagonal=1)
        return mask.masked_fill(mask == 1, float("-inf"))

    def _memory_mask(self) -> torch.Tensor:
        return torch.zeros(self.horizon, 1 + self.n_obs_steps)

    def _init_weights(self) -> None:
        for module in self.modules():
            if isinstance(module, (nn.Linear, nn.LayerNorm)):
                if isinstance(module, nn.Linear):
                    nn.init.normal_(module.weight, mean=0.0, std=0.02)
                    if module.bias is not None:
                        nn.init.zeros_(module.bias)
                else:
                    nn.init.ones_(module.weight)
                    nn.init.zeros_(module.bias)
        nn.init.normal_(self.pos_emb, mean=0.0, std=0.02)
        nn.init.normal_(self.cond_pos_emb, mean=0.0, std=0.02)

    def forward(
        self,
        sample: torch.Tensor,
        timesteps: torch.Tensor,
        cond: torch.Tensor,
        task_token: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if sample.ndim != 3 or sample.shape[1] != self.horizon:
            raise ValueError(f"Expected sample [B,{self.horizon},D], got {tuple(sample.shape)}")
        if cond.ndim != 3 or cond.shape[1] != self.n_obs_steps:
            raise ValueError(f"Expected cond [B,{self.n_obs_steps},D], got {tuple(cond.shape)}")
        time = self.time_emb(timesteps).to(dtype=sample.dtype).unsqueeze(1)
        memory = torch.cat([time, self.cond_obs_emb(cond)], dim=1)
        memory = self.cond_encoder(self.drop(memory + self.cond_pos_emb[:, : memory.shape[1]]))
        memory_mask = self.memory_mask
        if task_token is not None:
            if task_token.ndim == 2:
                task_token = task_token[:, None, :]
            if task_token.shape != (sample.shape[0], 1, self.embed_dim):
                raise ValueError(
                    f"Expected task_token [{sample.shape[0]},1,{self.embed_dim}], got {tuple(task_token.shape)}"
                )
            memory = torch.cat([memory, task_token.to(dtype=memory.dtype)], dim=1)
            memory_mask = F.pad(memory_mask, (0, 1), value=0.0)
        target = self.drop(self.input_emb(sample) + self.pos_emb[:, : sample.shape[1]])
        decoded = self.decoder(
            tgt=target,
            memory=memory,
            tgt_mask=self.target_mask.to(device=sample.device, dtype=sample.dtype),
            memory_mask=memory_mask.to(device=sample.device, dtype=sample.dtype),
        )
        return self.head(self.norm(decoded))
