"""Configuration for the DiffusionTransformer policy."""

from dataclasses import dataclass

from lerobot.configs import PreTrainedConfig
from lerobot.policies.actioncodec.configuration_chunk import ActionChunkConfig


@PreTrainedConfig.register_subclass("diffusion_transformer")
@dataclass
class DiffusionTransformerConfig(ActionChunkConfig):
    num_train_timesteps: int = 100
    beta_schedule: str = "squaredcos_cap_v2"
    prediction_type: str = "epsilon"
    num_inference_steps: int = 10
    eta: float = 0.0
    clip_sample: bool = True
    memory_mask_mode: str = "full_observation"

    def __post_init__(self) -> None:
        super().__post_init__()
        if (self.num_train_timesteps, self.num_inference_steps, self.eta) != (100, 10, 0.0):
            raise ValueError("Transformer DP requires 100 training timesteps and 10 DDIM steps with eta=0")
        if self.beta_schedule != "squaredcos_cap_v2" or self.prediction_type != "epsilon":
            raise ValueError("Transformer DP requires cosine betas and epsilon prediction")
        if not self.clip_sample or self.memory_mask_mode != "full_observation":
            raise ValueError("Transformer DP requires clipped samples and full observation attention")
