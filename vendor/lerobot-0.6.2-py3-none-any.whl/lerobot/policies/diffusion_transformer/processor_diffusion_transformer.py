"""Native min/max normalization and ActionCodec task mapping."""

from lerobot.policies.actioncodec.processor_actioncodec import (
    make_actioncodec_pre_post_processors as make_diffusion_transformer_pre_post_processors,
)

__all__ = ["make_diffusion_transformer_pre_post_processors"]
