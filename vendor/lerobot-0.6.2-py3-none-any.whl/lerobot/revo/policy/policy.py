"""ACT runtime adapter facade.

Algorithm-specific behavior is intentionally kept behind this small facade;
the protocol layer only knows the lifecycle and named observation contract.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from .adapter import ActObservationAdapter


class ACTPolicy:
    """Run a loaded ACT policy with contract-defined history semantics."""

    def __init__(self, loaded: Any):
        """Create a stateful ACT adapter from a :class:`LoadedPolicy`."""
        self.loaded = loaded
        self.adapter = ActObservationAdapter(loaded.contract)
        self.previous_observation: dict[str, Any] | None = None
        self.task_id: int | None = None

    def reset(self) -> None:
        """Clear model queues and temporal observation state."""
        self.loaded.policy.reset()
        self.previous_observation = None
        self.task_id = None

    def predict(self, observation: dict[str, Any]) -> dict[str, np.ndarray]:
        """Run one named observation through the model and return grouped actions."""
        import torch

        current = self.adapter.build_batch(observation)
        task_value = current.get("task_uid")
        current_task = int(task_value.reshape(-1)[0].item()) if task_value is not None else None
        if current_task != self.task_id:
            self.previous_observation = None
            self.task_id = current_task
        n_obs_steps = int(getattr(self.loaded.config, "n_obs_steps", 1))
        if n_obs_steps == 2:
            previous = self.previous_observation or current
            batch = self.adapter.add_temporal_batch_dim(self.adapter.stack_history(previous, current))
        else:
            batch = current
        self.previous_observation = self.adapter.copy_observation(current)
        processed = self.loaded.preprocessor(batch)
        with torch.inference_mode():
            output = self.loaded.policy.predict_action_chunk(processed)
        output = self.loaded.postprocessor(output)
        actions = np.asarray(output.detach().cpu().numpy(), dtype=np.float32)
        if actions.ndim == 3 and actions.shape[0] == 1:
            actions = actions[0]
        chunk_steps = int(self.loaded.contract.get("chunk_steps", actions.shape[0]))
        if actions.ndim != 2 or chunk_steps <= 0 or chunk_steps > actions.shape[0]:
            raise ValueError(f"policy output is incompatible with contract: shape={actions.shape}")
        return self.adapter.group_actions(actions[:chunk_steps])
