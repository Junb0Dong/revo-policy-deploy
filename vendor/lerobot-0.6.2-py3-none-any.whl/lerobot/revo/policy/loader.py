"""The only module allowed to load LeRobot policies from a deployment artifact."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..contract import POLICY_LOADER_VERSION, load_contract


@dataclass
class LoadedPolicy:
    """Loaded model, processors, configuration, and artifact metadata."""
    policy: Any
    preprocessor: Any
    postprocessor: Any
    config: Any
    model_dir: Path
    contract: dict[str, Any]


def load_policy(package_dir: str | Path, *, device: str = "auto") -> LoadedPolicy:
    """Load an ACT/LeRobot policy using only paths inside ``package_dir``."""
    package = Path(package_dir).expanduser().resolve()
    contract = load_contract(package)
    runtime = contract.get("runtime", {})
    compatibility = runtime.get("compatibility", {}) if isinstance(runtime, dict) else {}
    requested_loader = compatibility.get("policy_loader_version")
    if requested_loader is not None and str(requested_loader) != POLICY_LOADER_VERSION:
        raise ValueError(
            f"artifact requires policy loader {requested_loader}, current loader is {POLICY_LOADER_VERSION}"
        )
    requested_lerobot = compatibility.get("lerobot_version")
    if requested_lerobot not in (None, "", "unknown"):
        try:
            from importlib.metadata import version

            installed_lerobot = version("lerobot")
        except Exception:
            installed_lerobot = None
        if installed_lerobot is not None and str(installed_lerobot) != str(requested_lerobot):
            raise ValueError(
                f"artifact requires LeRobot {requested_lerobot}, installed {installed_lerobot}"
            )
    from ..runtime import load_train_config

    train_config = load_train_config(package, checkpoint_id=str(contract["checkpoint_id"]))
    model_dir = (package / str(train_config["runtime"]["model_dir"])).resolve()
    if package not in model_dir.parents:
        raise ValueError("runtime.model_dir escapes checkpoint artifact")
    import torch

    from lerobot.configs import PreTrainedConfig
    from lerobot.policies import get_policy_class, make_pre_post_processors

    resolved_device = _resolve_device(device, torch)
    config = PreTrainedConfig.from_pretrained(model_dir)
    config.device = resolved_device
    expected_family = contract.get("policy_family")
    if expected_family and str(config.type) != str(expected_family):
        raise ValueError(f"policy family mismatch: contract={expected_family!r}, config={config.type!r}")
    policy_cls = get_policy_class(config.type)
    policy = policy_cls.from_pretrained(model_dir, config=config)
    policy.eval()
    preprocessor, postprocessor = make_pre_post_processors(
        config,
        pretrained_path=str(model_dir),
        preprocessor_overrides={"device_processor": {"device": resolved_device}},
        postprocessor_overrides={"device_processor": {"device": "cpu"}},
    )
    return LoadedPolicy(policy, preprocessor, postprocessor, config, model_dir, contract)


def _resolve_device(device: str | None, torch: Any) -> str:
    if device in (None, "", "auto"):
        return "cuda" if torch.cuda.is_available() else "cpu"
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        return "cpu"
    return str(device)
