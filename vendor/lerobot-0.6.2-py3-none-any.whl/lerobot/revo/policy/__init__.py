"""Policy-side implementation for the portable Revo deployment artifact.

The package deliberately keeps model-specific imports behind :mod:`loader` so
contract inspection and protocol ``DESCRIBE`` do not import or instantiate a
large LeRobot policy.
"""

from .adapter import ActObservationAdapter
from .loader import LoadedPolicy, load_policy

__all__ = ["ActObservationAdapter", "LoadedPolicy", "load_policy"]
