"""LeRobot ACT runtime used by the Revo stdio inferencer and offline checks."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import yaml

from .contract import load_contract
from .policy.adapter import ActObservationAdapter


def load_train_config(package_dir: str | Path, *, checkpoint_id: str) -> dict[str, Any]:
    """Load and validate the generated public checkpoint header at LOAD time."""
    package_dir = Path(package_dir).expanduser().resolve()
    path = package_dir / "train_config.yaml"
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"cannot read train_config.yaml: {exc}") from exc
    if not isinstance(payload, dict):
        raise ValueError("train_config.yaml must contain an object")
    for field in ("generated", "do_not_edit"):
        if payload.get(field) is not True:
            raise ValueError(f"train_config.yaml requires {field}: true")
    if int(payload.get("schema_version", 0) or 0) <= 0:
        raise ValueError("train_config.yaml requires a positive schema_version")
    if not str(payload.get("generated_by", "")).strip():
        raise ValueError("train_config.yaml requires generated_by")
    if str(payload.get("checkpoint_id", "")) != checkpoint_id:
        raise ValueError("train_config.yaml checkpoint_id differs from policy_contract.json")
    runtime = payload.get("runtime")
    if not isinstance(runtime, dict):
        raise ValueError("train_config.yaml requires a runtime object")
    for field in ("weights", "model_config", "model_dir"):
        value = runtime.get(field)
        if not isinstance(value, str) or not value:
            raise ValueError(f"train_config.yaml runtime requires {field}")
        candidate = (package_dir / value).resolve()
        if package_dir not in candidate.parents and candidate != package_dir:
            raise ValueError(f"train_config.yaml runtime.{field} escapes checkpoint")
        if not candidate.exists():
            raise FileNotFoundError(f"train_config.yaml runtime.{field} is missing: {value}")
    content_hash = payload.get("content_sha256")
    if content_hash:
        import hashlib

        digest = hashlib.sha256()
        for field in ("weights", "model_config"):
            candidate = (package_dir / str(runtime[field])).resolve()
            digest.update(str(runtime[field]).encode("utf-8"))
            digest.update(candidate.read_bytes())
        if digest.hexdigest() != str(content_hash):
            raise ValueError("train_config.yaml content_sha256 mismatch")
    return payload


class RevoRuntime:
    """Load a packaged LeRobot policy and map named Revo observations to it."""

    def __init__(self, package_dir: str | Path, *, device: str | None = None):
        """Create a lazy runtime for a generated deployment package."""
        self.package_dir = Path(package_dir).expanduser().resolve()
        self.contract = load_contract(self.package_dir)
        self.model_dir = self.package_dir / "params" / "pretrained_model"
        self.device = device or str(self.contract.get("runtime", {}).get("device", "auto"))
        self.policy = None
        self.preprocessor = None
        self.postprocessor = None
        self._previous_observation: dict[str, Any] | None = None
        self._task_id: int | None = None
        self._history_enabled = False
        self._history_stride = int(self.contract.get("history_observation_stride", 0) or 0)
        self._model_horizon = int(self.contract.get("model_horizon", 0) or 0)
        self._adapter = ActObservationAdapter(self.contract)
        self._policy_adapter = None

    @staticmethod
    def _resolve_device(device: str) -> str:
        import torch

        if device in ("", "auto", None):
            return "cuda" if torch.cuda.is_available() else "cpu"
        if device.startswith("cuda") and not torch.cuda.is_available():
            return "cpu"
        return device

    def load(self) -> None:
        """Load the policy and its serialized pre/post-processors once."""
        if self.policy is not None:
            return
        from .policy.loader import load_policy
        from .policy.policy import ACTPolicy

        loaded = load_policy(self.package_dir, device=self.device)
        self.model_dir = loaded.model_dir
        self.device = str(getattr(loaded.config, "device", self.device))
        self.policy = loaded.policy
        self.preprocessor = loaded.preprocessor
        self.postprocessor = loaded.postprocessor
        config = loaded.config
        self._policy_adapter = ACTPolicy(loaded)
        self._history_enabled = int(getattr(config, "n_obs_steps", 1)) == 2
        configured_stride = int(getattr(config, "observation_stride", 0) or 0)
        if configured_stride > 0:
            self._history_stride = configured_stride
        if self._history_enabled and self._history_stride <= 0:
            raise ValueError("temporal Revo policies require a positive history_observation_stride")
        configured_horizon = int(getattr(config, "horizon", 0) or 0)
        if configured_horizon > 0:
            self._model_horizon = configured_horizon

    def reset(self) -> None:
        """Clear policy-side action queues and episode state."""
        policy_adapter = getattr(self, "_policy_adapter", None)
        if policy_adapter is not None:
            policy_adapter.reset()
        elif self.policy is not None:
            self.policy.reset()
        self._previous_observation = None
        self._task_id = None

    def predict(self, observation: dict[str, Any]) -> dict[str, np.ndarray]:
        """Predict one absolute action chunk from a named raw observation."""
        self.load()
        if self._policy_adapter is not None:
            return self._policy_adapter.predict(observation)
        assert self.policy is not None and self.preprocessor is not None and self.postprocessor is not None
        import torch

        current = self._build_batch(observation)
        current_task = None
        task_value = current.get("task_uid")
        if task_value is not None:
            current_task = int(task_value.reshape(-1)[0].item())
        if current_task != self._task_id:
            self._previous_observation = None
            self._task_id = current_task
        if self._history_enabled:
            previous = self._previous_observation or current
            batch = self._stack_history(previous, current)
            batch = self._add_temporal_batch_dim(batch)
        else:
            batch = current
        self._previous_observation = self._copy_observation(current)
        processed = self.preprocessor(batch)
        with torch.inference_mode():
            normalized_actions = self.policy.predict_action_chunk(processed)
        actions = self.postprocessor(normalized_actions)
        actions = np.asarray(actions.detach().cpu().numpy(), dtype=np.float32)
        if actions.ndim == 3 and actions.shape[0] == 1:
            actions = actions[0]
        if actions.ndim != 2 or not np.all(np.isfinite(actions)):
            raise ValueError(f"policy output must be finite [steps, dim], got {actions.shape}")
        chunk_steps = int(self.contract.get("chunk_steps", actions.shape[0]))
        if chunk_steps <= 0 or chunk_steps > actions.shape[0]:
            raise ValueError(
                f"contract chunk_steps={chunk_steps} is incompatible with policy output {actions.shape}"
            )
        actions = actions[:chunk_steps]
        return self._group_actions(actions)

    def _build_batch(self, observation: dict[str, Any]) -> dict[str, Any]:
        adapter = getattr(self, "_adapter", ActObservationAdapter(self.contract))
        return adapter.build_batch(observation)

    def _resolve_task_id(self, task: Any, task_index: Any) -> int | None:
        adapter = getattr(self, "_adapter", ActObservationAdapter(self.contract))
        return adapter.resolve_task_id(task, task_index)

    @staticmethod
    def _copy_observation(batch: dict[str, Any]) -> dict[str, Any]:
        return ActObservationAdapter.copy_observation(batch)

    @staticmethod
    def _stack_history(previous: dict[str, Any], current: dict[str, Any]) -> dict[str, Any]:
        return ActObservationAdapter.stack_history(previous, current)

    @staticmethod
    def _add_temporal_batch_dim(batch: dict[str, Any]) -> dict[str, Any]:
        """Add the leading batch dimension required by temporal policies.

        The regular observation processor adds a batch dimension to single
        observations, but it intentionally leaves already-temporal tensors
        unchanged. Runtime history is assembled as ``[T, ...]`` here, so it
        must be promoted to ``[1, T, ...]`` before entering that processor.
        Request metadata such as ``task_uid`` is already a batch vector and is
        kept unchanged.
        """
        return ActObservationAdapter.add_temporal_batch_dim(batch)

    def _group_actions(self, actions: np.ndarray) -> dict[str, np.ndarray]:
        return self._adapter.group_actions(actions)
