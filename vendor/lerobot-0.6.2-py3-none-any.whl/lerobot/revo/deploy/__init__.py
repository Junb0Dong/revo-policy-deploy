"""Deployment-side ABI and framed inferencer for portable Revo artifacts."""

from .policy_contract import load_contract, payload_hash

__all__ = ["load_contract", "payload_hash"]
