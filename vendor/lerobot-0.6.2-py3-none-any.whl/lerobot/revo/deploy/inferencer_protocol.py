"""Versioned framed-stdio protocol used by the deployment gateway."""

from ..protocol import recv_frame, send_frame

__all__ = ["recv_frame", "send_frame"]
