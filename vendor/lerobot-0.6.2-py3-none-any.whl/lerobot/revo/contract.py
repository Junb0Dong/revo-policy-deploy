"""Generated, immutable interface contract for a Revo deployment package."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

CONTRACT_FILENAME = "policy_contract.json"
PROTOCOL_VERSION = 1
SCHEMA_VERSION = 1
POLICY_LOADER_VERSION = "1"
JOINT_GROUP_ORDER = ("left_arm", "right_arm", "left_hand", "right_hand")


def load_contract(path_or_dir: str | Path) -> dict[str, Any]:
    """Load and verify a generated contract from a package or JSON path."""
    path = Path(path_or_dir).expanduser()
    if path.is_dir():
        path = path / CONTRACT_FILENAME
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"missing {CONTRACT_FILENAME}: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON contract: {path}") from exc
    if not isinstance(payload, dict):
        raise ValueError(f"contract must be a JSON object: {path}")
    if payload.get("generated") is not True or payload.get("do_not_edit") is not True:
        raise ValueError(f"contract must be generated and immutable: {path}")
    if int(payload.get("protocol_version", 0)) != PROTOCOL_VERSION:
        raise ValueError(f"unsupported protocol version: {payload.get('protocol_version')}")
    if "schema_version" in payload and int(payload.get("schema_version", 0) or 0) != SCHEMA_VERSION:
        raise ValueError(f"unsupported contract schema version: {payload.get('schema_version')}")
    expected = str(payload.get("contract_hash", ""))
    if not expected or expected != payload_hash(payload):
        raise ValueError(f"contract hash mismatch: {path}")
    _validate_shape_contract(payload, path)
    return payload


def payload_hash(payload: dict[str, Any]) -> str:
    """Hash a contract payload while excluding its self-referential hash field."""
    unsigned = {key: value for key, value in payload.items() if key != "contract_hash"}
    encoded = json.dumps(unsigned, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _validate_shape_contract(payload: dict[str, Any], path: Path) -> None:
    """Validate the deployment ABI while retaining compatibility with old tiny fixtures."""
    if "required_joint_groups" not in payload and "output_joint_groups" not in payload:
        return

    for key in ("checkpoint_id", "required_joint_groups", "required_cameras", "output_joint_groups"):
        if key not in payload:
            raise ValueError(f"contract missing required field {key!r}: {path}")
    if not isinstance(payload["checkpoint_id"], str) or not payload["checkpoint_id"].strip():
        raise ValueError(f"contract checkpoint_id must be a non-empty string: {path}")

    def validate_groups(value: Any, field: str) -> tuple[int, set[str]]:
        if not isinstance(value, dict) or not value:
            raise ValueError(f"contract {field} must be a non-empty object: {path}")
        keys = list(value)
        if any(key not in JOINT_GROUP_ORDER for key in keys):
            raise ValueError(f"contract {field} contains an unknown joint group: {path}")
        if keys != [key for key in JOINT_GROUP_ORDER if key in value]:
            raise ValueError(f"contract {field} must use canonical group order: {path}")
        names: set[str] = set()
        width = 0
        for group, group_names in value.items():
            if not isinstance(group_names, list) or not group_names:
                raise ValueError(f"contract {field}.{group} must be a non-empty list: {path}")
            normalized = [str(name) for name in group_names]
            if len(normalized) != len(set(normalized)):
                raise ValueError(f"contract {field}.{group} contains duplicate names: {path}")
            overlap = names.intersection(normalized)
            if overlap:
                raise ValueError(f"contract {field} repeats joint names {sorted(overlap)}: {path}")
            names.update(normalized)
            width += len(normalized)
        return width, names

    input_dim, _ = validate_groups(payload["required_joint_groups"], "required_joint_groups")
    output_dim, _ = validate_groups(payload["output_joint_groups"], "output_joint_groups")
    cameras = payload["required_cameras"]
    if not isinstance(cameras, list) or not cameras or len(cameras) != len(set(cameras)):
        raise ValueError(f"contract required_cameras must be a non-empty unique list: {path}")
    if payload.get("action_dim") is not None and int(payload["action_dim"]) != output_dim:
        raise ValueError(f"contract output groups do not cover action_dim: {path}")
    if payload.get("state_dim") is not None and int(payload["state_dim"]) != input_dim:
        raise ValueError(f"contract input groups do not cover state_dim: {path}")

    image_contract = payload.get("image_contract")
    if image_contract is not None:
        if not isinstance(image_contract, dict):
            raise ValueError(f"contract image_contract must be an object: {path}")
        resize = image_contract.get("resize_hw")
        native = image_contract.get("native_hw")
        if not isinstance(resize, list) or len(resize) != 2 or any(int(v) <= 0 for v in resize):
            raise ValueError(f"contract image_contract.resize_hw is invalid: {path}")
        if not isinstance(native, dict) or set(native) != set(cameras):
            raise ValueError(f"contract image_contract.native_hw must cover required cameras: {path}")
        for camera, shape in native.items():
            if not isinstance(shape, list) or len(shape) != 2 or any(int(v) <= 0 for v in shape):
                raise ValueError(f"contract native camera shape is invalid for {camera}: {path}")

    groups = payload.get("output_joint_groups")
    action_dim = payload.get("action_dim")
    if groups is not None and action_dim is not None and (
        not isinstance(groups, dict) or sum(len(value) for value in groups.values()) != int(action_dim)
    ):
        raise ValueError(f"output joint groups do not cover action_dim: {path}")
    chunk = payload.get("chunk_steps")
    horizon = payload.get("model_horizon")
    if chunk is not None and (int(chunk) <= 0 or (horizon is not None and int(chunk) > int(horizon))):
        raise ValueError(f"invalid chunk_steps/model_horizon: {path}")
    stride = payload.get("history_observation_stride")
    if stride is not None and int(stride) < 0:
        raise ValueError(f"history_observation_stride must be non-negative: {path}")
