"""Backward-compatible alias for the deployment inferencer."""

from .deploy.policy_inferencer import main, serve

__all__ = ["main", "serve"]

if __name__ == "__main__":
    main()


if __name__ == "__main__":
    main()
