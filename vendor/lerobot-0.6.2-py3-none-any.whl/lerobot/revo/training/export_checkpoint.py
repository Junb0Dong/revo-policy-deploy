"""Stable exporter module for training jobs."""

from ..export_checkpoint import export_checkpoint, main

__all__ = ["export_checkpoint", "main"]

if __name__ == "__main__":
    main()
