"""Export a portable LeRobot checkpoint and generated Revo contract."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

import yaml

from .contract import (
    CONTRACT_FILENAME,
    POLICY_LOADER_VERSION,
    PROTOCOL_VERSION,
    SCHEMA_VERSION,
    payload_hash,
)


def export_checkpoint(
    checkpoint: str | Path,
    dataset_root: str | Path,
    interface_config: str | Path,
    output: str | Path,
    *,
    device: str = "auto",
) -> Path:
    """Copy a LeRobot checkpoint and generate a self-contained Revo package."""
    checkpoint = Path(checkpoint).expanduser().resolve()
    dataset_root = Path(dataset_root).expanduser().resolve()
    interface_config = Path(interface_config).expanduser().resolve()
    output = Path(output).expanduser().resolve()
    ema_dir = checkpoint / "pretrained_model_ema"
    regular_dir = checkpoint / "pretrained_model"
    # Training writes a complete EMA model beside the live model when EMA is enabled.
    # Prefer it for deployment, while retaining compatibility with checkpoints without EMA.
    ema_complete = (ema_dir / "model.safetensors").is_file() and (ema_dir / "config.json").is_file()
    regular_complete = (regular_dir / "model.safetensors").is_file() and (regular_dir / "config.json").is_file()
    model_dir = ema_dir if ema_complete else (regular_dir if regular_complete else checkpoint)
    if not (model_dir / "model.safetensors").is_file() or not (model_dir / "config.json").is_file():
        raise FileNotFoundError(f"checkpoint must contain pretrained_model/model.safetensors: {checkpoint}")

    recipe = yaml.safe_load(interface_config.read_text(encoding="utf-8"))
    if not isinstance(recipe, dict) or not isinstance(recipe.get("io"), dict):
        raise ValueError(f"invalid Revo interface config: {interface_config}")
    io = recipe["io"]
    state_names = [str(name) for name in io["state_names"]]
    action_names = [str(name) for name in io["action_names"]]
    if state_names != action_names or len(state_names) != int(io.get("state_dim", len(state_names))):
        raise ValueError("Revo config must use identical state/action names and dimensions")

    info_path = dataset_root / "meta" / "info.json"
    info = json.loads(info_path.read_text(encoding="utf-8"))
    features = info.get("features", {})
    try:
        source_state = features["observation.state"]["names"]
        source_action = features["action"]["names"]
    except (KeyError, TypeError) as exc:
        raise ValueError("dataset metadata must define state/action names") from exc
    state_indices = _resolve_indices(source_state, state_names, "observation.state")
    action_indices = _resolve_indices(source_action, action_names, "action")
    camera_specs = io.get("cameras", [])
    camera_keys = [str(spec["dataset_key"]) for spec in camera_specs]
    camera_shapes = {}
    for spec in camera_specs:
        key = str(spec["dataset_key"])
        feature = features.get(key)
        if not isinstance(feature, dict):
            raise ValueError(f"camera missing from dataset metadata: {key}")
        shape = feature.get("shape")
        if not isinstance(shape, list) or len(shape) != 3:
            raise ValueError(f"camera has no shape metadata: {key}")
        if feature.get("dtype") not in (None, "video", "image", "uint8"):
            raise ValueError(f"camera must be an image/video feature: {key}")
        if int(shape[-1]) != 3:
            raise ValueError(f"camera must have three RGB channels: {key}")
        native_hw = [int(shape[0]), int(shape[1])]
        declared = [int(v) for v in spec.get("native_hw", native_hw)]
        if native_hw != declared:
            raise ValueError(
                f"camera native shape mismatch for {key}: config={declared}, dataset={native_hw}"
            )
        camera_shapes[key] = native_hw

    model_config = json.loads((model_dir / "config.json").read_text(encoding="utf-8"))
    model_action_dim = _model_action_dim(model_config)
    if model_action_dim != len(action_names):
        raise ValueError(f"checkpoint action dim {model_action_dim} != interface dim {len(action_names)}")
    model_state_dim = _model_state_dim(model_config)
    if model_state_dim is not None and model_state_dim != len(state_names):
        raise ValueError(f"checkpoint state dim {model_state_dim} != interface dim {len(state_names)}")
    chunk_steps = int(model_config.get("n_action_steps", model_config.get("chunk_size", 0)))
    if chunk_steps <= 0:
        raise ValueError("checkpoint has no positive action chunk size")
    resize_hw = [int(v) for v in io.get("image_resize_hw", [224, 224])]
    if len(resize_hw) != 2 or resize_hw[0] != resize_hw[1] or resize_hw[0] <= 0:
        raise ValueError(f"image_resize_hw must be a positive square: {resize_hw}")

    output.mkdir(parents=True, exist_ok=False)
    packaged_model = output / "params" / "pretrained_model"
    shutil.copytree(model_dir, packaged_model)
    assets = output / "assets"
    assets.mkdir()
    (assets / "dataset_info.json").write_text(
        json.dumps(info, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    task_map = _load_task_map(dataset_root)
    configured_tasks = int(model_config.get("num_tasks", len(task_map) or 1) or 1)
    if configured_tasks > 1 and len(task_map) < configured_tasks:
        raise ValueError("multi-task checkpoint requires a complete task map")
    if task_map:
        (assets / "tasks.json").write_text(
            json.dumps(task_map, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
    resolved = {
        "artifact_schema_version": SCHEMA_VERSION,
        "source_metadata": "assets/dataset_info.json",
        "interface_config": interface_config.name,
        "state_names": state_names,
        "action_names": action_names,
        "state_indices": state_indices,
        "action_indices": action_indices,
        "cameras": camera_keys,
        "native_camera_hw": camera_shapes,
        "model_input_hw": resize_hw,
        "fps": float(info["fps"]),
        "task_map": task_map,
    }
    (assets / "resolved_interface.json").write_text(
        json.dumps(resolved, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    groups = _groups(state_names, io.get("state_groups", []))
    output_groups = _groups(action_names, io.get("action_groups", []))
    model_horizon = int(model_config.get("horizon", model_config.get("chunk_size", chunk_steps)))
    history_stride = int(model_config.get("observation_stride", model_config.get("n_action_steps", 0)) or 0)
    action_stats = _load_action_stats(dataset_root, action_indices)
    tokenizer_stats_path = packaged_model / "tokenizer" / "action_stats.json"
    if tokenizer_stats_path.is_file():
        try:
            tokenizer_stats = json.loads(tokenizer_stats_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            tokenizer_stats = {}
        if action_stats and tokenizer_stats and not _stats_close(action_stats, tokenizer_stats):
            raise ValueError("dataset action stats do not match bundled tokenizer action_stats.json")
        if not action_stats:
            action_stats = {
                key: tokenizer_stats[key] for key in ("mean", "std") if key in tokenizer_stats
            }
    contract = {
        "schema_version": SCHEMA_VERSION,
        "generated": True,
        "do_not_edit": True,
        "generated_by": "lerobot.revo.export_checkpoint",
        "protocol_version": PROTOCOL_VERSION,
        "weights_variant": "ema" if model_dir == ema_dir or model_dir.name == "pretrained_model_ema" else "live",
        "checkpoint_id": f"{output.name}:{_file_sha256(packaged_model / 'model.safetensors')[:16]}",
        "policy_family": str(model_config.get("type", "")),
        "robot_interface": str(info.get("robot_type", "")),
        "required_joint_groups": groups,
        "required_cameras": camera_keys,
        "output_joint_groups": output_groups,
        "model_horizon": model_horizon,
        "chunk_steps": chunk_steps,
        "history_observation_stride": history_stride,
        "policy_rate_hz": float(info["fps"]),
        "action_dim": len(action_names),
        "state_dim": len(state_names),
        "latent_horizon": int(model_config.get("latent_horizon", 0) or 0),
        "num_tasks": max(1, configured_tasks),
        "task_map": task_map,
        "action_stats": action_stats,
        "inference_strategies": ["standard"],
        "action_semantics": str(io.get("action_semantics", "absolute_joint_position")),
        "image_contract": {
            "raw": {"dtype": "uint8", "layout": "HWC", "color": "RGB", "scale": "0to255"},
            "native_hw": camera_shapes,
            "resize_hw": resize_hw,
            "model_layout": "CHW_float32_0_1",
            "resize_method": "torch_bilinear_align_corners_false",
            "preprocessing_owner": "lerobot.revo",
        },
        "runtime": {
            "device": device,
            "model_dir": "params/pretrained_model",
            "compatibility": {
                "policy_loader_version": POLICY_LOADER_VERSION,
                "lerobot_version": _lerobot_runtime_version(),
            },
        },
    }
    contract["contract_hash"] = payload_hash(contract)
    (output / CONTRACT_FILENAME).write_text(
        json.dumps(contract, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    train_config = {
        "schema_version": SCHEMA_VERSION,
        "generated": True,
        "do_not_edit": True,
        "generated_by": "lerobot.revo.export_checkpoint",
        "format": "lerobot_revo_deploy_v1",
        "checkpoint_id": contract["checkpoint_id"],
        "policy_type": str(model_config.get("type", "")),
        "params_dir": "params/pretrained_model",
        "contract": CONTRACT_FILENAME,
        "runtime": {
            "weights": "params/pretrained_model/model.safetensors",
            "model_config": "params/pretrained_model/config.json",
            "model_dir": "params/pretrained_model",
        },
        "assets": {
            "resolved_interface": "assets/resolved_interface.json",
            "dataset_info": "assets/dataset_info.json",
        },
    }
    content_digest = hashlib.sha256()
    for field in ("weights", "model_config"):
        relative = train_config["runtime"][field]
        content_digest.update(relative.encode("utf-8"))
        content_digest.update((output / relative).read_bytes())
    train_config["content_sha256"] = content_digest.hexdigest()
    (output / "train_config.yaml").write_text(yaml.safe_dump(train_config, sort_keys=False), encoding="utf-8")
    return output


def _model_action_dim(model_config: dict[str, Any]) -> int:
    """Read the action width from ACT or ActionCodec model configuration."""
    features = model_config.get("output_features")
    if isinstance(features, dict) and isinstance(features.get("action"), dict):
        return int(features["action"]["shape"][-1])
    if "action_dim" in model_config:
        return int(model_config["action_dim"])
    raise ValueError("checkpoint config has no action feature shape or action_dim")


def _model_state_dim(model_config: dict[str, Any]) -> int | None:
    features = model_config.get("input_features")
    if isinstance(features, dict) and isinstance(features.get("observation.state"), dict):
        shape = features["observation.state"].get("shape")
        if isinstance(shape, (list, tuple)) and shape:
            return int(shape[-1])
    return None


def _lerobot_runtime_version() -> str:
    try:
        from importlib.metadata import version

        return version("lerobot")
    except Exception:
        return "unknown"


def _load_action_stats(dataset_root: Path, indices: list[int]) -> dict[str, Any]:
    path = dataset_root / "meta" / "stats.json"
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid dataset stats.json: {path}") from exc
    value = payload.get("action") if isinstance(payload, dict) else None
    if not isinstance(value, dict):
        raise ValueError("dataset stats.json must contain an action object")
    selected: dict[str, Any] = {}
    for key, raw in value.items():
        if key == "count":
            selected[key] = raw
            continue
        if not isinstance(raw, list) or len(raw) <= max(indices, default=-1):
            raise ValueError(f"dataset action stat {key!r} does not cover selected dimensions")
        selected[key] = [raw[index] for index in indices]
    return selected


def _stats_close(left: dict[str, Any], right: dict[str, Any], *, atol: float = 1e-6) -> bool:
    import numpy as np

    for key in ("mean", "std"):
        if key not in left or key not in right:
            return False
        if not np.allclose(np.asarray(left[key]), np.asarray(right[key]), rtol=1e-5, atol=atol):
            return False
    return True


def _load_task_map(dataset_root: Path) -> dict[str, int]:
    """Read the frozen text→task-id table used by ActionCodec task conditioning."""
    path = dataset_root / "meta" / "tasks.parquet"
    if not path.is_file():
        return {}
    try:
        import pandas as pd

        table = pd.read_parquet(path)
        if "task_index" not in table.columns:
            return {}
        tasks = table["task"].tolist() if "task" in table.columns else table.index.tolist()
        return {str(task): int(task_index) for task, task_index in zip(tasks, table["task_index"].tolist(), strict=True)}
    except Exception:
        return {}


def _resolve_indices(source: list[str], selected: list[str], key: str) -> list[int]:
    if len(source) != len(set(source)):
        raise ValueError(f"{key} metadata contains duplicate names")
    if len(selected) != len(set(selected)):
        raise ValueError(f"{key} interface contains duplicate names")
    positions = {name: index for index, name in enumerate(source)}
    missing = [name for name in selected if name not in positions]
    if missing:
        raise ValueError(f"{key} metadata is missing names: {missing}")
    return [positions[name] for name in selected]


def _groups(names: list[str], group_names: list[str]) -> dict[str, list[str]]:
    if not group_names:
        raise ValueError("joint group list must not be empty")
    groups: dict[str, list[str]] = {str(group): [] for group in group_names}
    for name in names:
        if name.startswith("left_arm_joint"):
            group = "left_arm"
        elif name.startswith("right_arm_joint"):
            group = "right_arm"
        elif name.startswith("left_"):
            group = "left_hand"
        elif name.startswith("right_"):
            group = "right_hand"
        else:
            raise ValueError(f"cannot infer joint group for {name!r}")
        if group not in groups:
            raise ValueError(f"joint {name!r} belongs to undeclared group {group!r}")
        groups[group].append(name)
    return groups


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    """Run the exporter command line interface."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--dataset-root", required=True)
    parser.add_argument("--interface-config", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    print(
        export_checkpoint(
            args.checkpoint, args.dataset_root, args.interface_config, args.output, device=args.device
        )
    )


if __name__ == "__main__":
    main()
